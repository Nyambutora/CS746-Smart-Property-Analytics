# References
# https://docs.streamlit.io/develop/api-reference/layout/st.tabs
# https://docs.streamlit.io/develop/api-reference/data/st.data_editor
# https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html

from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Smart Property Analytics", layout="wide")
st.title("Smart Property Analytics")

# Using the models folder beside app.py.
models_folder = Path(__file__).resolve().parent / "models"
prediction_tab, evaluation_tab, eda_tab, interpretation_tab = st.tabs(
    ["Predict", "Model Evaluation", "Data and Exploratory Analysis",
     "Model Interpretation"]
)

with prediction_tab:
    model_files = [
        "xgboost_price_model.joblib",
        "random_forest_condition_model.joblib",
        "dashboard_inputs.joblib",
    ]
    missing_models = [
        name for name in model_files if not (models_folder / name).is_file()
    ]

    if missing_models:
        st.error("Missing prediction files: " + ", ".join(missing_models))
    else:
        price_model = joblib.load(models_folder / model_files[0])
        condition_model = joblib.load(models_folder / model_files[1])
        inputs = joblib.load(models_folder / model_files[2])

        st.write("Edit the example property. Scroll right to see all fields.")
        st.caption("Overall Cond is used for the sale price estimate only.")

        with st.form("property_input"):
            property_data = st.data_editor(
                inputs["example_property"], hide_index=True, num_rows="fixed"
            )
            submitted = st.form_submit_button("Predict")

        if submitted:
            # Sending each pipeline its own feature columns in training order.
            price = price_model.predict(property_data[inputs["price_columns"]])[0]
            condition = condition_model.predict(
                property_data[inputs["condition_columns"]]
            )[0]

            price_panel, condition_panel = st.columns(2)
            price_panel.metric("Estimated sale price", f"${price:,.2f}")
            condition_panel.metric("Predicted condition category", str(condition))
            st.caption("The condition categories are derived from Ames assessor ratings.")

with evaluation_tab:
    evaluation_files = [
        "price_test_results.csv",
        "condition_test_results.csv",
        "condition_confusion_matrix.csv",
    ]
    missing_results = [
        name for name in evaluation_files if not (models_folder / name).is_file()
    ]

    if missing_results:
        st.info(
            "Run the Exporting Model Evaluation Results cell in Jupyter. "
            "Missing files: " + ", ".join(missing_results)
        )
    else:
        # Loading the notebook's held-out results without retraining.
        price_results = pd.read_csv(models_folder / evaluation_files[0])
        condition_results = pd.read_csv(
            models_folder / evaluation_files[1], index_col=0
        )
        confusion = pd.read_csv(
            models_folder / evaluation_files[2], index_col=0
        )

        st.subheader("Sale Price Prediction")
        st.dataframe(price_results.round(4), hide_index=True)

        st.subheader("Property Condition Classification")
        st.dataframe(condition_results.round(4))

        st.subheader("Confusion Matrix")
        st.caption("Rows show actual categories. Columns show predicted categories.")
        st.dataframe(confusion)

        high_correct = int(confusion.loc["High", "High"])
        high_total = int(confusion.loc["High"].sum())
        st.write(
            f"The model correctly flagged {high_correct} of the "
            f"{high_total} properties in the High category."
        )

with eda_tab:
    missing_path = models_folder / "missing_values_summary.csv"
    eda_path = models_folder / "housing_eda.csv"

    if missing_path.is_file() and eda_path.is_file():
        missing_summary = pd.read_csv(missing_path)
        eda_data = pd.read_csv(eda_path)

        st.subheader("Missing Values Before and After Cleaning")
        st.caption("Counts reflect the notebook cleaning steps before model imputation.")
        st.dataframe(missing_summary, hide_index=True)

        st.subheader("Above-Ground Living Area and Sale Price")
        st.caption(f"Each point represents one of {len(eda_data):,} Ames properties.")
        chart_data = eda_data.rename(columns={
            "Gr Liv Area": "Above-ground living area (sq ft)",
            "SalePrice": "Sale price ($)",
        })
        st.scatter_chart(
            chart_data,
            x="Above-ground living area (sq ft)",
            y="Sale price ($)",
        )
    else:
        st.info("Run the exploratory data export cell in Jupyter first.")

with interpretation_tab:
    sections = [
        (
            "Sale Price Feature Importance",
            "price_feature_importance.csv",
            "How much test MAE increased after shuffling each feature.",
            2,
        ),
        (
            "Property Condition Feature Importance",
            "condition_feature_importance.csv",
            "How much test macro F1 decreased after shuffling each feature.",
            4,
        ),
        (
            "SHAP Explanation for the Prefilled Property",
            "example_house_shap.csv",
            "Positive contributions raised the model estimate relative to its "
            "baseline. Negative contributions lowered it. The table shows "
            "the ten largest contributions by absolute value.",
            2,
        ),
    ]

    for title, filename, description, decimals in sections:
        st.subheader(title)
        st.caption(description)
        table_path = models_folder / filename

        if table_path.is_file():
            st.dataframe(pd.read_csv(table_path).round(decimals), hide_index=True)
        else:
            st.info(f"Run the notebook interpretation export to create {filename}.")
